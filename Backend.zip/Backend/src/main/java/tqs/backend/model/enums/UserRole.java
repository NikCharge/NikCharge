package tqs.backend.model.enums;

public enum UserRole {
    CLIENT,
    EMPLOYEE,
    MANAGER
}
