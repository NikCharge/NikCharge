package tqs.backend.model.enums;

public enum ChargerType {
    AC_STANDARD,
    DC_FAST,
    DC_ULTRA_FAST
}
