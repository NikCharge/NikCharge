package tqs.backend.model.enums;

public enum ChargerStatus {
    AVAILABLE,
    IN_USE,
    UNDER_MAINTENANCE
}