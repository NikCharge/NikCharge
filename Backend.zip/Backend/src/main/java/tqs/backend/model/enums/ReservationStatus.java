package tqs.backend.model.enums;

public enum ReservationStatus {
    ACTIVE,
    CANCELLED,
    COMPLETED,
}
